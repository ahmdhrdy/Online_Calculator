package com.example.calculator_midterm;

import java.util.ArrayList;

public class Handler {

    public void handleIt(Object... parameters) {

    }
}
